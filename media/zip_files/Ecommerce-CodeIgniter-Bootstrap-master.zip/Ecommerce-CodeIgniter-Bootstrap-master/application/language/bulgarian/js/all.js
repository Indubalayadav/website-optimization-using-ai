﻿var lang = {
    added_to_cart: "Добавено в кошницата",
    error_to_cart: "Проблем с кошницата! Опитайте пак!",
    no_products: "Нямате продукти",
    confirm_clear_cart: "Сигурни ли сте, че искате да изпразните количката?",
    cleared_cart: "Кошницата е изпразнена",
    are_you_sure: "Сигурни ли сте?",
    yes: "Да",
    no: "Не",
    clear_all: "Изчисти",
    checkout: "Плащане",
    remove_from_cart: "Изтрито от кошницата",
    enter_valid_email: "Моля въведете валиден имейл адрес",
    discountCodeInvalid: "Кода е невалиден"
};